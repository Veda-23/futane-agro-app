package com.futaneagro.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.futaneagro.entity.*;
import com.futaneagro.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.io.File;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EnterpriseController {

    @Autowired
    private MachineMasterRepository machineRepo;

    @Autowired
    private MachineBreakdownRepository breakdownRepo;

    @Autowired
    private DispatchRepository dispatchRepo;

    @Autowired
    private ExpenseRepository expenseRepo;

    @Autowired
    private BankTransactionRepository bankRepo;

    @Autowired
    private SettingsRepository settingsRepo;

    @Autowired
    private AuditLogRepository auditRepo;

    @Autowired
    private ObjectMapper objectMapper;

    private String getCurrentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return (principal != null) ? principal.toString() : "system";
    }

    private void saveAuditLog(String action, String tableName, String oldValue, String newValue) {
        AuditLog log = new AuditLog();
        log.setUsername(getCurrentUser());
        log.setAction(action);
        log.setTableName(tableName);
        log.setOldValue(oldValue);
        log.setNewValue(newValue);
        auditRepo.save(log);
    }

    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            return "";
        }
    }

    // --- Machine Master ---
    @GetMapping("/machines")
    public List<MachineMaster> getAllMachines() {
        return machineRepo.findAll();
    }

    @PostMapping("/machines")
    public MachineMaster createMachine(@RequestBody MachineMaster machine) {
        MachineMaster saved = machineRepo.save(machine);
        saveAuditLog("Created machine: " + saved.getMachineName(), "Machine_Master", null, toJson(saved));
        return saved;
    }

    @PutMapping("/machines/{id}")
    public MachineMaster updateMachine(@PathVariable Integer id, @RequestBody MachineMaster details) {
        MachineMaster machine = machineRepo.findById(id).orElseThrow(() -> new RuntimeException("Machine not found"));
        String oldState = toJson(machine);
        
        machine.setMachineName(details.getMachineName());
        machine.setManufacturer(details.getManufacturer());
        machine.setPurchaseDate(details.getPurchaseDate());
        machine.setWarrantyDate(details.getWarrantyDate());
        machine.setStatus(details.getStatus());
        
        MachineMaster saved = machineRepo.save(machine);
        saveAuditLog("Updated machine: " + saved.getMachineName(), "Machine_Master", oldState, toJson(saved));
        return saved;
    }

    @DeleteMapping("/machines/{id}")
    public void deleteMachine(@PathVariable Integer id) {
        machineRepo.findById(id).ifPresent(machine -> {
            String oldState = toJson(machine);
            machine.setIsDeleted(true);
            machine.setDeletedBy(getCurrentUser());
            machine.setDeletedDate(LocalDate.now());
            machineRepo.save(machine);
            saveAuditLog("Soft-deleted machine ID: " + id, "Machine_Master", oldState, null);
        });
    }

    // --- Machine Breakdown ---
    @GetMapping("/breakdowns")
    public List<MachineBreakdown> getAllBreakdowns() {
        return breakdownRepo.findAll();
    }

    @PostMapping("/breakdowns")
    public MachineBreakdown createBreakdown(@RequestBody MachineBreakdown breakdown) {
        MachineBreakdown saved = breakdownRepo.save(breakdown);
        saveAuditLog("Logged breakdown for machine ID: " + saved.getMachine().getMachineId(), "Machine_Breakdown", null, toJson(saved));
        return saved;
    }

    @DeleteMapping("/breakdowns/{id}")
    public void deleteBreakdown(@PathVariable Integer id) {
        breakdownRepo.findById(id).ifPresent(b -> {
            String oldState = toJson(b);
            b.setIsDeleted(true);
            b.setDeletedBy(getCurrentUser());
            b.setDeletedDate(LocalDate.now());
            breakdownRepo.save(b);
            saveAuditLog("Soft-deleted breakdown ID: " + id, "Machine_Breakdown", oldState, null);
        });
    }

    // --- Dispatch ---
    @GetMapping("/dispatches")
    public List<Dispatch> getAllDispatches() {
        return dispatchRepo.findAll();
    }

    @PostMapping("/dispatches")
    public Dispatch createDispatch(@RequestBody Dispatch dispatch) {
        Dispatch saved = dispatchRepo.save(dispatch);
        saveAuditLog("Created dispatch log: " + saved.getDispatchNumber(), "Dispatch", null, toJson(saved));
        return saved;
    }

    @PutMapping("/dispatches/{id}")
    public Dispatch updateDispatch(@PathVariable Integer id, @RequestBody Dispatch details) {
        Dispatch dispatch = dispatchRepo.findById(id).orElseThrow(() -> new RuntimeException("Dispatch not found"));
        String oldState = toJson(dispatch);
        
        dispatch.setVehicleNumber(details.getVehicleNumber());
        dispatch.setDriverName(details.getDriverName());
        dispatch.setDate(details.getDate());
        dispatch.setStatus(details.getStatus());
        
        Dispatch saved = dispatchRepo.save(dispatch);
        saveAuditLog("Updated dispatch: " + saved.getDispatchNumber(), "Dispatch", oldState, toJson(saved));
        return saved;
    }

    @DeleteMapping("/dispatches/{id}")
    public void deleteDispatch(@PathVariable Integer id) {
        dispatchRepo.findById(id).ifPresent(d -> {
            String oldState = toJson(d);
            d.setIsDeleted(true);
            d.setDeletedBy(getCurrentUser());
            d.setDeletedDate(LocalDate.now());
            dispatchRepo.save(d);
            saveAuditLog("Soft-deleted dispatch ID: " + id, "Dispatch", oldState, null);
        });
    }

    // --- Expense ---
    @GetMapping("/expenses")
    public List<Expense> getAllExpenses() {
        return expenseRepo.findAll();
    }

    @PostMapping("/expenses")
    public Expense createExpense(@RequestBody Expense expense) {
        Expense saved = expenseRepo.save(expense);
        saveAuditLog("Created expense entry: " + saved.getCategory(), "Expense", null, toJson(saved));
        return saved;
    }

    @DeleteMapping("/expenses/{id}")
    public void deleteExpense(@PathVariable Integer id) {
        expenseRepo.findById(id).ifPresent(e -> {
            String oldState = toJson(e);
            e.setIsDeleted(true);
            e.setDeletedBy(getCurrentUser());
            e.setDeletedDate(LocalDate.now());
            expenseRepo.save(e);
            saveAuditLog("Soft-deleted expense ID: " + id, "Expense", oldState, null);
        });
    }

    // --- Bank Transactions ---
    @GetMapping("/bank-transactions")
    public List<BankTransaction> getAllTransactions() {
        return bankRepo.findAll();
    }

    @PostMapping("/bank-transactions")
    public BankTransaction createTransaction(@RequestBody BankTransaction transaction) {
        BankTransaction saved = bankRepo.save(transaction);
        saveAuditLog("Created bank transaction: " + saved.getMode(), "Bank_Transaction", null, toJson(saved));
        return saved;
    }

    @DeleteMapping("/bank-transactions/{id}")
    public void deleteTransaction(@PathVariable Integer id) {
        bankRepo.findById(id).ifPresent(t -> {
            String oldState = toJson(t);
            t.setIsDeleted(true);
            t.setDeletedBy(getCurrentUser());
            t.setDeletedDate(LocalDate.now());
            bankRepo.save(t);
            saveAuditLog("Soft-deleted bank transaction ID: " + id, "Bank_Transaction", oldState, null);
        });
    }

    // --- Settings (For Power BI URL) ---
    @GetMapping("/settings/{key}")
    public ResponseEntity<Settings> getSetting(@PathVariable String key) {
        Optional<Settings> setting = settingsRepo.findById(key);
        return setting.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.ok(new Settings(key, "")));
    }

    @GetMapping("/settings")
    public List<Map<String, String>> getAllSettings() {
        return settingsRepo.findAll().stream().map(s -> {
            Map<String, String> map = new HashMap<>();
            map.put("settingKey", s.getConfigKey());
            map.put("settingValue", s.getConfigValue());
            return map;
        }).collect(Collectors.toList());
    }

    @PostMapping("/settings")
    public Settings saveSetting(@RequestBody Map<String, String> payload) {
        String key = payload.get("settingKey");
        String value = payload.get("settingValue");
        if (key == null) {
            key = payload.get("configKey");
            value = payload.get("configValue");
        }
        Settings settings = new Settings(key, value);
        Settings saved = settingsRepo.save(settings);
        saveAuditLog("Updated settings key: " + saved.getConfigKey(), "Settings", null, toJson(saved));
        return saved;
    }

    @GetMapping("/settings/backups")
    public ResponseEntity<?> getBackups() {
        File folder = new File("backups");
        if (!folder.exists() || !folder.isDirectory()) {
            return ResponseEntity.ok(Collections.emptyList());
        }
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".sql"));
        List<Map<String, Object>> list = new ArrayList<>();
        if (files != null) {
            for (File f : files) {
                Map<String, Object> item = new HashMap<>();
                item.put("filename", f.getPath().replace("\\", "/"));
                item.put("name", f.getName());
                item.put("size", f.length());
                item.put("lastModified", new java.util.Date(f.lastModified()).toString());
                list.add(item);
            }
        }
        return ResponseEntity.ok(list);
    }

    @PostMapping("/settings/backup")
    public ResponseEntity<?> runBackup() {
        try {
            String activeProfile = System.getProperty("spring.profiles.active", "uat");
            String dbName = "futane_erp_" + activeProfile;
            String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
            String filename = "backups/" + dbName + "_backup_" + timestamp + ".sql";
            
            File backupFolder = new File("backups");
            if (!backupFolder.exists()) {
                backupFolder.mkdirs();
            }
            
            String command = String.format("mysqldump -u root -pVedant %s > %s", dbName, filename);
            ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", command);
            Process process = pb.start();
            int exitCode = process.waitFor();
            
            if (exitCode == 0) {
                saveAuditLog("Triggered manual database backup: " + filename, "Settings", null, null);
                Map<String, String> res = new HashMap<>();
                res.put("status", "success");
                res.put("message", "Backup created successfully: " + filename);
                return ResponseEntity.ok(res);
            } else {
                return ResponseEntity.status(500).body("Backup failed with exit code: " + exitCode);
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Backup error: " + e.getMessage());
        }
    }

    @PostMapping("/settings/restore")
    public ResponseEntity<?> runRestore(@RequestBody Map<String, String> payload) {
        String filename = payload.get("filename");
        if (filename == null) {
            return ResponseEntity.badRequest().body("Filename is required.");
        }
        try {
            String activeProfile = System.getProperty("spring.profiles.active", "uat");
            String dbName = "futane_erp_" + activeProfile;
            
            File backupFile = new File(filename);
            if (!backupFile.exists()) {
                return ResponseEntity.notFound().build();
            }
            
            String command = String.format("mysql -u root -pVedant %s < %s", dbName, filename);
            ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", command);
            Process process = pb.start();
            int exitCode = process.waitFor();
            
            if (exitCode == 0) {
                saveAuditLog("Restored database from backup: " + filename, "Settings", null, null);
                Map<String, String> res = new HashMap<>();
                res.put("status", "success");
                res.put("message", "Database restored successfully from: " + filename);
                return ResponseEntity.ok(res);
            } else {
                return ResponseEntity.status(500).body("Restore failed with exit code: " + exitCode);
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Restore error: " + e.getMessage());
        }
    }
}
