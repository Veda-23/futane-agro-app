# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tests\e2e_payment.spec.js >> Razorpay E2E Payment Test >> Should complete payment via Razorpay Test Card
- Location: tests\e2e_payment.spec.js:6:3

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: page.fill: Test timeout of 90000ms exceeded.
Call log:
  - waiting for locator('input[name="salesDate"]')

```

# Page snapshot

```yaml
- generic [ref=e5]:
  - generic [ref=e6]:
    - generic [ref=e7]:
      - generic [ref=e8]: 🏭
      - heading "Futane Agro Industries" [level=1] [ref=e9]
      - paragraph [ref=e10]: Pvt. Ltd.
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]: 📦
        - generic [ref=e14]:
          - strong [ref=e15]: Inventory Control
          - paragraph [ref=e16]: Real-time stock tracking
      - generic [ref=e17]:
        - generic [ref=e18]: 📊
        - generic [ref=e19]:
          - strong [ref=e20]: Sales & Revenue
          - paragraph [ref=e21]: GST invoicing & collections
      - generic [ref=e22]:
        - generic [ref=e23]: ⚙️
        - generic [ref=e24]:
          - strong [ref=e25]: Production
          - paragraph [ref=e26]: Machine & shift monitoring
      - generic [ref=e27]:
        - generic [ref=e28]: 👥
        - generic [ref=e29]:
          - strong [ref=e30]: HR & Payroll
          - paragraph [ref=e31]: Employee salary management
    - generic [ref=e32]: System Online | v2.0 Production Ready
  - generic [ref=e34]:
    - generic [ref=e35]:
      - heading "Welcome Back" [level=2] [ref=e36]
      - paragraph [ref=e37]: Sign in to your ERP dashboard
    - generic [ref=e38]:
      - generic [ref=e39]:
        - generic [ref=e40]: 🔐
        - heading "Two-Factor Verification" [level=3] [ref=e41]
        - paragraph [ref=e42]:
          - text: OTP generated for
          - strong [ref=e43]: admin
      - generic [ref=e44] [cursor=pointer]:
        - generic [ref=e45]: 🔒 Your OTP (click to auto-fill)
        - generic [ref=e46]: "113648"
        - generic [ref=e47]: Valid for 0:32 · Click to fill automatically
      - generic [ref=e48]:
        - generic [ref=e49]:
          - text: 🔢 Enter 6-Digit OTP
          - generic [ref=e50]: ⏱ 0:32
        - textbox "🔢 Enter 6-Digit OTP ⏱ 0:32" [ref=e51]:
          - /placeholder: ● ● ● ● ● ●
      - button "Verify & Login ✓" [ref=e52] [cursor=pointer]:
        - generic [ref=e53]: Verify & Login
        - text: ✓
      - generic [ref=e54]:
        - button "🔄 Resend OTP" [disabled] [ref=e55]
        - button "← Back" [ref=e56] [cursor=pointer]
    - generic [ref=e57]:
      - button "EN" [ref=e58] [cursor=pointer]
      - generic [ref=e59]: "|"
      - button "मराठी" [ref=e60] [cursor=pointer]
      - generic [ref=e61]: "|"
      - button "हिंदी" [ref=e62] [cursor=pointer]
```

# Test source

```ts
  1   | const { test, expect } = require('@playwright/test');
  2   | 
  3   | test.use({ ignoreHTTPSErrors: true });
  4   | 
  5   | test.describe('Razorpay E2E Payment Test', () => {
  6   |   test('Should complete payment via Razorpay Test Card', async ({ page }) => {
  7   |     test.setTimeout(90000); // 90 seconds
  8   | 
  9   |     console.log('Logging in...');
  10  |     await page.goto('https://80.225.192.171/', { waitUntil: 'networkidle' });
  11  |     
  12  |     if (await page.isVisible('input[name="username"]')) {
  13  |       await page.fill('input[name="username"]', 'admin');
  14  |       await page.fill('input[name="password"]', 'admin123');
  15  |       await page.click('button[type="submit"]');
  16  |       await page.waitForTimeout(3000); // Wait for login transition
  17  |     }
  18  | 
  19  |     console.log('Navigating to Sales...');
  20  |     await page.click('text=Sales');
  21  |     await page.waitForTimeout(3000); // wait for component to mount
  22  |     
  23  |     // Take a screenshot to see where we are
  24  |     await page.screenshot({ path: 'sales_page.png' });
  25  |     console.log('Saved screenshot to sales_page.png');
  26  |     
  27  |     console.log('Clicking Pay Now...');
  28  |     const payNowBtns = page.locator('button:has-text("Pay Now")');
  29  |     const count = await payNowBtns.count();
  30  |     
  31  |     if (count > 0) {
  32  |       console.log(`Found ${count} Pay Now buttons. Clicking the first one.`);
  33  |       await payNowBtns.first().click();
  34  |       
  35  |       // SweetAlert2 input
  36  |       await page.waitForSelector('.swal2-input', { timeout: 10000 });
  37  |       await page.fill('.swal2-input', '10');
  38  |       await page.click('.swal2-confirm');
  39  |       
  40  |       console.log('Waiting for Razorpay Modal...');
  41  |       const iframeElement = await page.waitForSelector('.razorpay-checkout-frame', { state: 'attached', timeout: 15000 });
  42  |       await page.screenshot({ path: 'razorpay_modal.png' });
  43  |       
  44  |       const frame = await iframeElement.contentFrame();
  45  |       if (!frame) throw new Error("Could not find Razorpay frame content.");
  46  | 
  47  |       console.log('Interacting with Razorpay iframe...');
  48  |       const isContactVisible = await frame.isVisible('input#contact', { timeout: 5000 }).catch(() => false);
  49  |       if (isContactVisible) {
  50  |         await frame.fill('input#contact', '9999999999');
  51  |         await frame.click('button#redesign-v15-cta');
  52  |       }
  53  | 
  54  |       await frame.waitForSelector('button[method="card"]', { timeout: 15000 });
  55  |       await frame.click('button[method="card"]');
  56  | 
  57  |       console.log('Filling Card Details...');
  58  |       await frame.fill('input#card_number', '4111 1111 1111 1111');
  59  |       await frame.fill('input#card_expiry', '12/26');
  60  |       await frame.fill('input#card_name', 'Test User');
  61  |       await frame.fill('input#card_cvv', '123');
  62  | 
  63  |       await frame.click('button#redesign-v15-cta');
  64  |       await page.waitForTimeout(2000);
  65  |       
  66  |       // Select SUCCESS on Razorpay test gateway
  67  |       const successBtn = frame.locator('button:has-text("Success")').first();
  68  |       if (await successBtn.isVisible()) {
  69  |           await successBtn.click();
  70  |       }
  71  | 
  72  |       console.log('Waiting for success confirmation in Main Window...');
  73  |       await page.waitForSelector('h2:has-text("Payment Receipt")', { timeout: 20000 });
  74  |       await page.screenshot({ path: 'receipt.png' });
  75  |       
  76  |       console.log('✅ Payment Receipt verified successfully!');
  77  |       expect(true).toBe(true);
  78  | 
  79  |     } else {
  80  |       console.log('No unpaid sales available to test. Creating a dummy sale...');
  81  |       
  82  |       // Let's create a quick dummy sale to test it
> 83  |       await page.fill('input[name="salesDate"]', new Date().toISOString().split('T')[0]);
      |                  ^ Error: page.fill: Test timeout of 90000ms exceeded.
  84  |       
  85  |       // Fill the first party from dropdown
  86  |       const firstOption = await page.$eval('select[name="salesParty"] option:nth-child(2)', el => el.value).catch(() => '1');
  87  |       await page.selectOption('select[name="salesParty"]', firstOption);
  88  |       
  89  |       await page.selectOption('select[name="salesCrateType"]', 'Apple Crate');
  90  |       await page.fill('input[name="salesMaterial"]', 'Plastic');
  91  |       await page.fill('input[name="salesQty"]', '1');
  92  |       await page.fill('input[name="salesRate"]', '100');
  93  |       await page.fill('input[name="salesPaid"]', '0');
  94  |       await page.click('button:has-text("Save Record")');
  95  |       
  96  |       console.log('Saved dummy sale. Waiting for refresh...');
  97  |       await page.waitForTimeout(2000);
  98  |       
  99  |       const newPayNow = page.locator('button:has-text("Pay Now")').first();
  100 |       await newPayNow.click();
  101 |       
  102 |       await page.waitForSelector('.swal2-input');
  103 |       await page.fill('.swal2-input', '10');
  104 |       await page.click('.swal2-confirm');
  105 |       
  106 |       const iframeElement = await page.waitForSelector('.razorpay-checkout-frame', { state: 'attached', timeout: 15000 });
  107 |       const frame = await iframeElement.contentFrame();
  108 |       
  109 |       const isContactVisible = await frame.isVisible('input#contact', { timeout: 5000 }).catch(() => false);
  110 |       if (isContactVisible) {
  111 |         await frame.fill('input#contact', '9999999999');
  112 |         await frame.click('button#redesign-v15-cta');
  113 |       }
  114 | 
  115 |       await frame.waitForSelector('button[method="card"]', { timeout: 15000 });
  116 |       await frame.click('button[method="card"]');
  117 | 
  118 |       await frame.fill('input#card_number', '4111 1111 1111 1111');
  119 |       await frame.fill('input#card_expiry', '12/26');
  120 |       await frame.fill('input#card_name', 'Test User');
  121 |       await frame.fill('input#card_cvv', '123');
  122 | 
  123 |       await frame.click('button#redesign-v15-cta');
  124 |       await page.waitForTimeout(2000);
  125 |       
  126 |       const successBtn = frame.locator('button:has-text("Success")').first();
  127 |       if (await successBtn.isVisible()) {
  128 |           await successBtn.click();
  129 |       }
  130 | 
  131 |       await page.waitForSelector('h2:has-text("Payment Receipt")', { timeout: 20000 });
  132 |       console.log('✅ Payment Receipt verified successfully on newly created invoice!');
  133 |     }
  134 |   });
  135 | });
  136 | 
```